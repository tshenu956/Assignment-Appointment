import {
  MAT_TOOLTIP_DEFAULT_OPTIONS,
  MAT_TOOLTIP_SCROLL_STRATEGY,
  MatTooltip,
  SCROLL_THROTTLE_MS,
  TOOLTIP_PANEL_CLASS,
  TooltipComponent,
  getMatTooltipInvalidPositionError
} from "./chunk-PMFHGI4R.js";
import {
  OverlayModule
} from "./chunk-ISXKFINF.js";
import "./chunk-IKXHTYIT.js";
import {
  A11yModule
} from "./chunk-4QONZTIF.js";
import "./chunk-73QY4FJF.js";
import "./chunk-PLJ2QXBA.js";
import "./chunk-Z2NNI556.js";
import "./chunk-EIMN7UOP.js";
import "./chunk-N4DOILP3.js";
import "./chunk-EATFOGFT.js";
import "./chunk-YT5QHJDZ.js";
import "./chunk-NLAC6XR3.js";
import {
  CdkScrollableModule
} from "./chunk-X5VTC3EU.js";
import "./chunk-EMZ5E5WN.js";
import "./chunk-GUGIMSVJ.js";
import "./chunk-BLZ7TTCW.js";
import "./chunk-OFUNLWWM.js";
import "./chunk-PKKTVRJO.js";
import "./chunk-LPJU6VAH.js";
import "./chunk-ULVKYUJB.js";
import {
  BidiModule
} from "./chunk-46X3TXMV.js";
import {
  NgModule,
  setClassMetadata,
  ɵɵdefineInjector,
  ɵɵdefineNgModule
} from "./chunk-S6V62GTH.js";
import "./chunk-PJVWDKLX.js";

// node_modules/@angular/material/fesm2022/tooltip.mjs
var MatTooltipModule = class _MatTooltipModule {
  static ɵfac = function MatTooltipModule_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || _MatTooltipModule)();
  };
  static ɵmod = ɵɵdefineNgModule({
    type: _MatTooltipModule,
    imports: [A11yModule, OverlayModule, MatTooltip, TooltipComponent],
    exports: [MatTooltip, TooltipComponent, BidiModule, CdkScrollableModule]
  });
  static ɵinj = ɵɵdefineInjector({
    imports: [A11yModule, OverlayModule, BidiModule, CdkScrollableModule]
  });
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(MatTooltipModule, [{
    type: NgModule,
    args: [{
      imports: [A11yModule, OverlayModule, MatTooltip, TooltipComponent],
      exports: [MatTooltip, TooltipComponent, BidiModule, CdkScrollableModule]
    }]
  }], null, null);
})();
export {
  MAT_TOOLTIP_DEFAULT_OPTIONS,
  MAT_TOOLTIP_SCROLL_STRATEGY,
  MatTooltip,
  MatTooltipModule,
  SCROLL_THROTTLE_MS,
  TOOLTIP_PANEL_CLASS,
  TooltipComponent,
  getMatTooltipInvalidPositionError
};
//# sourceMappingURL=@angular_material_tooltip.js.map
