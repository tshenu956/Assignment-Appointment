import {
  MatDivider,
  MatDividerModule
} from "./chunk-UXL4U2N3.js";
import "./chunk-PLJ2QXBA.js";
import "./chunk-N4DOILP3.js";
import "./chunk-BLZ7TTCW.js";
import "./chunk-46X3TXMV.js";
import "./chunk-S6V62GTH.js";
import "./chunk-PJVWDKLX.js";
export {
  MatDivider,
  MatDividerModule
};
