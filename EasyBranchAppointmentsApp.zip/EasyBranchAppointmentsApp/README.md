# EasyBranchAppointmentsApp

Angular 21 frontend for the EasyBranchAppointments system. Provides a public-facing booking form for customers and a protected admin dashboard for managing branches, time slots, bookings and appointment types.

---

## Table of Contents

- [Technology Stack](#technology-stack)
- [Project Structure](#project-structure)
- [Architecture & Design Patterns](#architecture--design-patterns)
- [Pages & Components](#pages--components)
- [Services](#services)
- [Models](#models)
- [Routing & Guards](#routing--guards)
- [Authentication](#authentication)
- [Docker](#docker)
- [Environment Configuration](#environment-configuration)
- [Running Locally](#running-locally)
- [Building for Production](#building-for-production)

---

## Technology Stack

| Technology | Version | Purpose |
|------------|---------|---------|
| **Angular** | 21.2 | SPA framework |
| **Angular Material** | 21.2 | Material Design 3 UI component library |
| **Angular CDK** | 21.2 | Overlay, scrolling, portal primitives |
| **TypeScript** | 5.9 | Strongly typed JavaScript |
| **RxJS** | 7.8 | Reactive HTTP streams and async composition |
| **Zone.js** | 0.15 | Angular change detection |
| **Nginx** | alpine | Static file server (production container) |
| **Node.js** | 22-alpine | Build environment (not in the runtime image) |

---

## Project Structure

```
src/
├── app/
│   ├── app.ts                         # Root component (<app-toolbar />)
│   ├── app.config.ts                  # Application bootstrap (providers)
│   ├── app.routes.ts                  # Route definitions
│   ├── auth.guard.ts                  # Route guard for /admin
│   │
│   ├── booking/                       # Customer booking page (public)
│   │   ├── Booking.Component.ts
│   │   ├── booking-confirmation-dialog.component.ts  # Simulated email shown after booking
│   │   ├── booking.html
│   │   └── booking.css
│   │
│   ├── login/                         # Admin login page
│   │   ├── login.ts
│   │   ├── login.html
│   │   └── login.css
│   │
│   ├── admin-dashboard/               # Admin management dashboard (protected)
│   │   ├── admin-dashboard.ts
│   │   ├── admin-dashboard.html
│   │   └── admin-dashboard.css
│   │
│   ├── shared/
│   │   ├── toolbar.component/         # App shell: sidenav + topbar + router-outlet
│   │   │   └── toolbar.component.ts   # Inline template and styles
│   │   ├── confirm-dialog/            # Reusable Angular Material confirm dialog
│   │   │   └── confirm-dialog.component.ts
│   │   └── credentials-dialog/        # One-time credentials display after admin registration
│   │       └── credentials-dialog.component.ts
│   │
│   ├── services/
│   │   ├── AuthService.ts             # JWT login / logout / token storage
│   │   ├── auth.interceptor.ts        # HTTP interceptor — attaches Bearer token
│   │   ├── branchService.ts           # Branch CRUD API calls
│   │   ├── timeslotService.ts         # Time slot API calls
│   │   ├── booking.Service.ts         # Booking API calls (create, list, cancel, lookup)
│   │   └── appointmentTypeService.ts  # Appointment type API calls
│   │
│   └── models/
│       ├── booking.model.ts
│       ├── branch.model.ts
│       ├── timeslot.model.ts
│       ├── appointment-type.model.ts
│       └── index.ts
│
├── environments/
│   └── environment.ts                 # API base URL config
│
├── styles.css                         # Global styles + Angular Material theme import
└── index.html                         # Shell HTML
```

---

## Architecture & Design Patterns

The app follows a **Feature-Based Layered Architecture**:

```
┌──────────────────────────────────────────────────────┐
│  Presentation Layer                                  │
│  Components / Templates / Angular Material           │
│  BookingComponent · AdminDashboardComponent · Login  │
├──────────────────────────────────────────────────────┤
│  Service Layer                                       │
│  BranchService · TimeslotService · BookingService    │
│  AuthService · AppointmentTypeService                │
├──────────────────────────────────────────────────────┤
│  HTTP Layer                                          │
│  HttpClient  +  authInterceptor (Bearer token)       │
├──────────────────────────────────────────────────────┤
│  External API                                        │
│  EasyBranchAppointments .NET 8 REST API              │
└──────────────────────────────────────────────────────┘
```

### Design Patterns

| Pattern | Description |
|---------|-------------|
| **Standalone Components** | Every component uses `standalone: true` with explicit `imports[]`. No `NgModule` anywhere in the project. |
| **Functional DI (`inject()`)** | Services are injected with `inject()` (Angular 16+ functional DI) instead of constructor parameters, reducing boilerplate. |
| **HTTP Interceptor (functional)** | `authInterceptor` is a plain function registered via `withInterceptors([authInterceptor])`. Clones every outgoing request and attaches `Authorization: Bearer <token>`. Components never manage headers manually. |
| **Route Guard** | `AuthGuard.canActivate()` — unauthenticated access to `/admin` redirects to `/login`. |
| **Service Layer** | Each API resource has one dedicated typed service. Components call service methods; no component ever uses `HttpClient` directly. |
| **Reactive Forms** | All forms use `FormBuilder` + `FormGroup` with built-in Angular validators. |
| **`MatTableDataSource`** | Admin tables use `MatTableDataSource<T>` which provides client-side pagination, sorting and filtering hooks out of the box. |
| **Setter-based `@ViewChild`** | Paginators inside `@if` blocks are wired via setter syntax (`set branchPaginator(p: MatPaginator)`). Angular calls the setter the instant the element enters the DOM, connecting the data source immediately rather than waiting for `ngAfterViewInit` (which runs before API data arrives). |
| **Server-side Pagination** | The Bookings table sends `?page=N&pageSize=N` to the API and binds the paginator `[length]` to the `totalCount` from the response. |
| **DTO Pattern** | TypeScript interfaces in `models/` mirror the API response shapes exactly. `CreateBookingDto` separates the write shape from the read shape. |
| **Observable Pipeline** | All HTTP calls return `Observable<T>`. RxJS operators (`map`, `filter`, `tap`, `pipe`, `finalize`, `timeout`) compose async logic declaratively. |
| **Reusable Confirm Dialog** | A single `ConfirmDialogComponent` handles all destructive action confirmations via `MatDialog`. A private `confirm(data)` helper in the dashboard returns `Observable<boolean>`, replacing all `window.confirm()` calls. |

---

## Pages & Components

### `BookingComponent` — `/`

Public. No authentication required.

**Flow:**
1. Loads all branches and appointment types from the API on init
2. When branch + date are selected, fetches available time slots for that date
3. Slots already booked or whose start time has passed today are automatically hidden
4. Customer fills in name and email and submits the form
5. On success a `BookingConfirmationDialogComponent` opens showing a simulated confirmation email with the booking reference, branch, date, time, and appointment purpose; on conflict or past-slot the API returns a descriptive error

**Angular Material components:** `mat-card`, `mat-form-field`, `mat-select`, `mat-input`, `mat-datepicker`, `mat-raised-button`, `mat-icon`, `mat-spinner`, `mat-divider`, `mat-error`

---

### `Login` — `/login`

**Flow:**
1. Form collects username and password
2. `AuthService.login()` POST → JWT stored in `localStorage`
3. Navigate to `/admin` on success
4. RxJS `timeout(15000)` operator shows a clear message if the API is unreachable

New admin accounts are created exclusively from the **Admins tab** in the admin dashboard.

**Angular Material components:** `mat-card`, `mat-form-field`, `mat-input`, `mat-raised-button`, `mat-icon`, `mat-snack-bar`, `mat-spinner`, `mat-divider`

---

### `AdminDashboardComponent` — `/admin`

Protected by `AuthGuard`. Five tabs. The dashboard is locked to the viewport height — tab headers are always visible and only the active tab body scrolls.

| Tab | Data strategy | Pagination |
|-----|--------------|------------|
| **Branches** | `MatTableDataSource<Branch>` | Client-side — 5 / 10 / 25 per page |
| **Time Slots** | `MatTableDataSource<TimeSlot>` | Client-side — 5 / 10 / 25 per page |
| **Bookings** | API array | **Server-side** — `?page=N&pageSize=N`, 5 / 10 / 25 / 50 per page |
| **Appointment Types** | `MatTableDataSource<AppointmentType>` | Client-side — 5 / 10 / 25 per page |
| **Admins** | `MatTableDataSource` | Client-side — 5 / 10 / 25 per page |

**Branches tab:** create branch, edit branch inline, delete single or bulk delete (skips branches with related data), active branch selector in page header.

**Time Slots tab:** visual slot generator (from/to + duration → preview list), remove individual slots before saving, bulk-save, delete single or bulk delete (blocked if slot has any bookings).

**Bookings tab:** filter by date, server-side paginated table, cancel single or bulk cancel, status badges (CONFIRMED / CANCELLED), checkbox multi-select.

**Appointment Types tab:** create type (name + optional description), delete type.

**Admins tab:** register new admin — a secure random password is auto-generated and shown once in a `CredentialsDialogComponent` (simulated welcome email with copy-to-clipboard); delete admin (self-deletion blocked).

**All destructive actions** open `ConfirmDialogComponent` — no browser `confirm()` dialogs.

**Angular Material components:** `mat-tab-group`, `mat-tab`, `mat-table`, `mat-paginator`, `mat-card`, `mat-form-field`, `mat-select`, `mat-input`, `mat-datepicker`, `mat-checkbox`, `mat-raised-button`, `mat-stroked-button`, `mat-icon-button`, `mat-icon`, `mat-tooltip`, `mat-spinner`, `mat-snack-bar`, `mat-divider`, `mat-dialog`

---

### `AppToolbarComponent` — (App Shell)

Rendered in `app.html` as `<app-toolbar />`. Wraps the entire app.

- **`mat-sidenav-container`** — full-height shell (`height: 100vh`)
- **Side drawer** (`mat-sidenav mode="over"`) — navigation links and logout
- **Top bar** (`mat-toolbar position: sticky`) — hamburger toggle, app title, login/logout
- **`<router-outlet />`** — all pages render here

`cdkScrollable` is applied to `mat-sidenav-content` and `overflow-y: auto` is set on it. Both are required for Angular CDK overlays (`mat-select`, `mat-datepicker`, `mat-tooltip`) to calculate panel positions correctly. Without this, `mat-sidenav-container`'s internal CSS transforms break `position: fixed` overlay positioning, causing all dropdowns to render at the top-left corner of the page.

---

### `ConfirmDialogComponent` — (Shared)

| Input (`MAT_DIALOG_DATA`) | Type | Default | Description |
|---------------------------|------|---------|-------------|
| `title` | `string` | — | Dialog heading |
| `message` | `string` | — | Body text |
| `confirmLabel` | `string` | `'Confirm'` | Confirm button label |
| `confirmColor` | `'primary'` \| `'accent'` \| `'warn'` | `'warn'` | Confirm button colour |

Returns `true` via `afterClosed()` on confirm, `false`/`undefined` on cancel or backdrop click.

---

### `CredentialsDialogComponent` — (Shared)

Shown after a new admin is registered. Presents a simulated welcome email with the auto-generated username and password. Includes a **Copy Credentials** button that writes both to the clipboard. The dialog is non-dismissable (`disableClose: true`) to prevent accidentally closing before copying.

| Input (`MAT_DIALOG_DATA`) | Type | Description |
|---------------------------|------|-------------|
| `username` | `string` | The newly registered admin username |
| `password` | `string` | The auto-generated password (shown once) |

---

### `BookingConfirmationDialogComponent` — (Booking)

Shown after a customer successfully books an appointment. Presents a simulated confirmation email with full booking details.

| Input (`MAT_DIALOG_DATA`) | Type | Description |
|---------------------------|------|-------------|
| `bookingId` | `number` | Booking reference number |
| `customerName` | `string` | Customer's full name |
| `customerEmail` | `string` | Customer's email address |
| `branchName` | `string` | Branch name |
| `appointmentDate` | `string` | Date in `YYYY-MM-DD` format |
| `timeSlot` | `string` | Formatted time range (e.g. `09:00 – 09:30`) |
| `appointmentType` | `string` | Appointment purpose name |

---

## Services

### `AuthService`

JWT stored in `localStorage` under key `appointment.jwt`.

| Method | Description |
|--------|-------------|
| `login(username, password)` | `POST /api/auth/login` → stores token, returns `Observable<{ token }>` |
| `register(username, password)` | `POST /api/auth/register` (requires existing admin JWT) |
| `logout()` | Removes token from `localStorage` |
| `isLoggedIn()` | `true` if a token is present |
| `token` | Getter — returns stored JWT or `null` |
| `getAuthHeaders()` | Returns `HttpHeaders` with `Authorization: Bearer` |

### `authInterceptor` (functional)

Registered globally in `app.config.ts` via `provideHttpClient(withInterceptors([authInterceptor]))`. Reads the token from `AuthService` and clones every request to add the header. No component or service needs to handle this manually.

### `BranchService`

| Method | API call |
|--------|----------|
| `getBranches()` | `GET /api/branch` |
| `createBranch(branch)` | `POST /api/branch` |
| `updateBranch(id, branch)` | `PUT /api/branch/{id}` |
| `deleteBranch(id)` | `DELETE /api/branch/{id}` |
| `deleteBranchesBulk(ids)` | `DELETE /api/branch/bulk` |

### `TimeslotService`

| Method | API call |
|--------|----------|
| `getSlots(branchId, date)` | `GET /api/timeslot/{branchId}?date=YYYY-MM-DD` |
| `getByBranch(branchId)` | `GET /api/timeslot/branch/{branchId}` |
| `createSlot(branchId, start, end)` | `POST /api/timeslot` |
| `createSlotsBulk(branchId, slots)` | `POST /api/timeslot/bulk` |
| `deleteSlot(id)` | `DELETE /api/timeslot/{id}` |
| `deleteSlotsBulk(ids)` | `DELETE /api/timeslot/bulk` |

### `BookingService`

| Method | API call | Used by |
|--------|----------|---------|
| `create(dto)` | `POST /api/booking` | Customer booking form |
| `list(branchId?, date?)` | `GET /api/booking` (extracts `.items`) | Backward compat |
| `listPaged(branchId?, date?, page, pageSize)` | `GET /api/booking?page=&pageSize=` | Admin Bookings tab |
| `cancel(id)` | `DELETE /api/booking/{id}` | Admin cancel single |
| `cancelBulk(ids)` | `DELETE /api/booking/bulk` | Admin bulk cancel |

`listPaged()` returns `BookingPage { items, totalCount, totalPages, page, pageSize }` for server-side paginator binding.

### `AppointmentTypeService`

| Method | API call |
|--------|----------|
| `getAll()` | `GET /api/appointmenttype` |
| `create(name, description)` | `POST /api/appointmenttype` |
| `update(id, name, description)` | `PUT /api/appointmenttype/{id}` |
| `delete(id)` | `DELETE /api/appointmenttype/{id}` |

---

## Models

```typescript
interface Branch {
  id: number;
  name: string;
  address: string;
}

interface TimeSlot {
  id: number;
  branchId: number;
  startTime: string;       // "09:00"
  endTime: string;         // "10:00"
  isAvailable?: boolean;   // populated by the public availability endpoint
}

interface Booking {
  id: number;
  branchId: number;
  timeSlotId: number;
  appointmentDate: string; // "YYYY-MM-DD"
  customerName: string;
  customerEmail: string;
  status: 'CONFIRMED' | 'CANCELLED' | string;
  appointmentTypeId?: number;
  appointmentTypeName?: string;
}

interface CreateBookingDto {
  branchId: number;
  timeSlotId: number;
  appointmentDate: string;
  customerName: string;
  customerEmail: string;
  appointmentTypeId?: number;
}

interface AppointmentType {
  id: number;
  name: string;
  description: string;
}
```

---

## Routing & Guards

```typescript
{ path: '',      component: BookingComponent }                           // public
{ path: 'login', component: Login }                                      // public
{ path: 'admin', component: AdminDashboardComponent,
                 canActivate: [AuthGuard] }                              // protected
{ path: '**',    redirectTo: '' }                                        // fallback
```

`AuthGuard` calls `AuthService.isLoggedIn()`. If no token is in `localStorage`, the user is redirected to `/login`. After successful login the user is navigated to `/admin`.

---

## Authentication

```
Admin enters credentials
        │
        ▼
POST /api/auth/login
        │
        ▼
JWT received → localStorage.setItem('appointment.jwt', token)
        │
        ▼
authInterceptor clones every request → Authorization: Bearer <token>
        │
        ▼
AuthGuard checks token before activating /admin route
        │
        ▼
Logout → localStorage.removeItem('appointment.jwt')
```

**Note:** `localStorage` is accessible to page JavaScript. For higher-security requirements, `HttpOnly` cookies are preferred. The current approach is appropriate for an internal admin tool on a trusted network.

---

## Docker

The full stack (Angular + API + PostgreSQL) is orchestrated from the **sibling API repository** using a single Docker Compose file. You do not need to run any Docker commands from this repository directly.

```bash
# From the API repository — builds and starts all three services
cd ../EasyBranchAppointments
docker compose up --build -d

# Rebuild only the Angular image (e.g. after frontend changes)
docker compose build angular --no-cache
docker compose up -d

# Stop all services
docker compose down
```

| Service | Host port | Container port |
|---------|-----------|----------------|
| Angular (Nginx) | 4200 | 80 |
| .NET API | 5000 | 8080 |
| PostgreSQL | 5432 | 5432 |

### How the Angular image is built

Two-stage Dockerfile:

```
Stage 1 — Build  (node:22-alpine)
  ├─ npm ci
  ├─ ng build  →  dist/EasyBranchAppointmentsApp/browser/
  └─ Trusts Zscaler corporate CA during build (NODE_EXTRA_CA_CERTS)

Stage 2 — Runtime  (nginx:alpine)
  ├─ Copy static files from stage 1
  ├─ Copy nginx.conf
  └─ EXPOSE 80
```

The final image contains **only static files and Nginx** — no Node.js, no Angular CLI, no source code.

`nginx.conf` includes `try_files $uri $uri/ /index.html` so Angular's client-side routing works correctly on direct URL access and page refresh.

---

## Environment Configuration

`src/environments/environment.ts`:

```typescript
export const environment = {
  production: false,
  apiBase: 'http://localhost:5000'
};
```

`apiBase` is baked into the bundle at build time. For production, update this to the public URL of the API **as the browser sees it** (not the Docker-internal hostname) before running `docker compose up --build`.

---

## Running Locally

### Prerequisites

- Node.js 22+
- npm 11+
- The API running at `http://localhost:5000`

### Start

```bash
npm install
npm start
```

App at `http://localhost:4200`. The dev server calls `http://localhost:5000` directly (no proxy). CORS for `localhost:4200` is enabled in `appsettings.Development.json` by default.

### Run tests

```bash
npm test
```

Uses **Vitest** as the test runner.

---

## Building for Production

```bash
npm run build
```

Output: `dist/EasyBranchAppointmentsApp/browser/`

The Docker build runs `npm run build` automatically — no local build step is needed before `docker compose up --build`.

> **Bundle size note:** The initial bundle slightly exceeds Angular's default 1 MB budget. To reduce it, consider lazy-loading the admin dashboard route and importing Angular Material modules per-component rather than in bulk.
