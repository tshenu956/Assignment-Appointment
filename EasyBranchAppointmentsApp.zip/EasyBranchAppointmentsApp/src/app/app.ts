import { Component } from '@angular/core';
import { AppToolbarComponent } from './shared/toolbar.component/toolbar.component';

@Component({
  selector: 'app-root',
  imports: [AppToolbarComponent],
  templateUrl: './app.html',
  styleUrl: './app.css'
})
export class App {}
