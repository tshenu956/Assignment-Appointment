export interface Booking {
  id: number;
  branchId: number;
  timeSlotId: number;
  appointmentDate: string;
  customerName: string;
  customerEmail: string;
  status: 'CONFIRMED' | 'CANCELLED' | string;
  appointmentTypeId?: number;
  appointmentTypeName?: string;
}

export interface CreateBookingDto {
  branchId: number;
  timeSlotId: number;
  appointmentDate: string; // "YYYY-MM-DD"
  customerName: string;
  customerEmail: string;
  appointmentTypeId?: number;
}
