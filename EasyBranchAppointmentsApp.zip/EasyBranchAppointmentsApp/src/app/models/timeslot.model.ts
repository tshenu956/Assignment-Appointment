export interface TimeSlot {
    id: number;
    branchId: number;
    startTime: string;   // e.g., "09:00:00"
    endTime: string;     // e.g., "09:30:00"
    isAvailable?: boolean; // Returned by /api/timeslots/{branchId}?date=...
  }