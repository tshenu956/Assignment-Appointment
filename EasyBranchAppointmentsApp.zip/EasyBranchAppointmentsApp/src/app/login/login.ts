import { ChangeDetectorRef, Component, inject, NgZone } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, Validators, ReactiveFormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { MatCardModule } from '@angular/material/card';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatButtonModule } from '@angular/material/button';
import { MatSnackBar, MatSnackBarModule } from '@angular/material/snack-bar';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { MatIconModule } from '@angular/material/icon';
import { finalize, timeout } from 'rxjs';
import { AuthService } from '../services/AuthService';

@Component({
  selector: 'app-login',
  imports: [
    
CommonModule,
ReactiveFormsModule,
// Material
MatCardModule,
MatFormFieldModule,
MatInputModule,
MatButtonModule,
MatSnackBarModule,
MatProgressSpinnerModule,
MatIconModule,
],
  templateUrl: './login.html',
  styleUrl: './login.css',
})
export class Login {

  
private fb = inject(FormBuilder);
private auth = inject(AuthService);
private router = inject(Router);
private snack = inject(MatSnackBar);
private cdr = inject(ChangeDetectorRef);
private ngZone = inject(NgZone);

loading = false;
hidePassword = true;

form = this.fb.group({
  username: ['', [Validators.required, Validators.minLength(3)]],
  password: ['', [Validators.required, Validators.minLength(4)]],
});

get f() { return this.form.controls; }


login(): void {
  if (this.form.invalid) {
    this.form.markAllAsTouched();
    this.open('Please enter username and password');
    return;
  }

  
const { username, password } = this.form.value;
this.loading = true;
this.auth.login(username!, password!).pipe(
  timeout(15000),
  finalize(() => { this.ngZone.run(() => { this.loading = false; }); })
).subscribe({
  next: () => this.ngZone.run(() => {
    this.loading = false;
    this.open('Login successful');
    this.router.navigateByUrl('/admin');
  }),
  error: (err) => this.ngZone.run(() => {
    this.loading = false;
    this.open(err?.name === 'TimeoutError'
      ? 'Login timed out. Check that the backend is running.'
      : 'Invalid credentials');
  })
});
}


private open(message: string) {
  this.snack.open(message, 'Close', { duration: 3000 });
}

}
