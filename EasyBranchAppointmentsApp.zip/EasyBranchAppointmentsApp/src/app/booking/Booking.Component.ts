import { Component, OnInit, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, Validators, ReactiveFormsModule } from '@angular/forms';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatSelectModule } from '@angular/material/select';
import { MatInputModule } from '@angular/material/input';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatNativeDateModule } from '@angular/material/core';
import { MatButtonModule } from '@angular/material/button';
import { MatSnackBar, MatSnackBarModule } from '@angular/material/snack-bar';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { MatCardModule } from '@angular/material/card';
import { MatDividerModule } from '@angular/material/divider';
import { MatIconModule } from '@angular/material/icon';
import { MatDialog, MatDialogModule } from '@angular/material/dialog';
import { BookingConfirmationDialogComponent, BookingConfirmationDialogData } from './booking-confirmation-dialog.component';

import { Branch } from '../models/branch.model';
import { TimeSlot } from '../models/timeslot.model';
import { AppointmentType } from '../models/appointment-type.model';
import { BookingService } from '../services/booking.Service';
import { BranchService } from '../services/branchService';
import { TimeslotService } from '../services/timeslotService';
import { AppointmentTypeService } from '../services/appointmentTypeService';

@Component({
  selector: 'app-booking',
  standalone: true,
  imports: [
    CommonModule,
    ReactiveFormsModule,
    MatFormFieldModule,
    MatSelectModule,
    MatInputModule,
    MatDatepickerModule,
    MatNativeDateModule,
    MatButtonModule,
    MatSnackBarModule,
    MatProgressSpinnerModule,
    MatCardModule,
    MatDividerModule,
    MatIconModule,
    MatDialogModule
  ],
  templateUrl: './booking.html',
  styleUrls: ['./booking.css']
})
export class BookingComponent implements OnInit {

  private fb = inject(FormBuilder);
  private branchService = inject(BranchService);
  private timeSlotService = inject(TimeslotService);
  private bookingService = inject(BookingService);
  private appointmentTypeService = inject(AppointmentTypeService);
  private snack = inject(MatSnackBar);
  private dialog = inject(MatDialog);

  form = this.fb.group({
    branchId:          [null as number | null, Validators.required],
    appointmentDate:   [null as Date | null,   Validators.required],
    appointmentTypeId: [null as number | null, Validators.required],
    timeSlotId:        [null as number | null, Validators.required],
    customerName:      ['', [Validators.required, Validators.minLength(2)]],
    customerEmail:     ['', [Validators.required, Validators.email]]
  });

  readonly minDate = new Date();

  branches: Branch[] = [];
  slots: TimeSlot[] = [];
  appointmentTypes: AppointmentType[] = [];

  loadingBranches = false;
  loadingSlots = false;
  loadingTypes = false;
  submitting = false;

  ngOnInit(): void {
    this.loadBranches();
    this.loadAppointmentTypes();
    this.form.get('branchId')?.valueChanges.subscribe(() => this.tryLoadSlots());
    this.form.get('appointmentDate')?.valueChanges.subscribe(() => this.tryLoadSlots());
  }

  loadBranches(): void {
    this.loadingBranches = true;
    this.branchService.getBranches().subscribe({
      next: (branches) => { this.branches = branches; this.loadingBranches = false; },
      error: () => { this.loadingBranches = false; this.openSnack('Failed to load branches. Please try again.'); }
    });
  }

  loadAppointmentTypes(): void {
    this.loadingTypes = true;
    this.appointmentTypeService.getAll().subscribe({
      next: (types) => { this.appointmentTypes = types; this.loadingTypes = false; },
      error: () => { this.loadingTypes = false; }
    });
  }

  tryLoadSlots(): void {
    const branchId = this.form.get('branchId')?.value;
    const date = this.form.get('appointmentDate')?.value as Date | null;
    if (!branchId || !date) { this.slots = []; this.form.get('timeSlotId')?.reset(); return; }

    this.loadingSlots = true;
    this.timeSlotService.getSlots(+branchId, date).subscribe({
      next: (slots) => {
        this.slots = (slots ?? []).filter(s => s.isAvailable !== false);
        this.loadingSlots = false;
        const selected = this.form.get('timeSlotId')?.value;
        if (selected && !this.slots.some(s => s.id === selected)) this.form.get('timeSlotId')?.reset();
      },
      error: (err) => {
        this.loadingSlots = false;
        const status = err?.status;
        if (status === 0) this.openSnack('Cannot reach the server. Ensure the backend is running.');
        else this.openSnack(`Failed to load time slots${status ? ' (' + status + ')' : ''}.`);
      }
    });
  }

  submit(): void {
    if (this.form.invalid) { this.form.markAllAsTouched(); this.openSnack('Please fill in all required fields.'); return; }

    const dto = {
      branchId:          +this.form.value.branchId!,
      timeSlotId:        +this.form.value.timeSlotId!,
      appointmentDate:   this.formatDate(this.form.value.appointmentDate!),
      customerName:      this.form.value.customerName!.trim(),
      customerEmail:     this.form.value.customerEmail!.trim(),
      appointmentTypeId: this.form.value.appointmentTypeId ?? undefined
    };

    const branchName = this.branches.find(b => b.id === dto.branchId)?.name ?? '';
    const slot = this.slots.find(s => s.id === dto.timeSlotId);
    const typeName = this.appointmentTypes.find(t => t.id === dto.appointmentTypeId)?.name ?? '';

    this.submitting = true;
    this.bookingService.create(dto).subscribe({
      next: (booking) => {
        this.submitting = false;
        const branchId = this.form.value.branchId;
        const appointmentDate = this.form.value.appointmentDate;
        this.form.reset();
        this.form.patchValue({ branchId, appointmentDate });
        this.tryLoadSlots();
        this.dialog.open(BookingConfirmationDialogComponent, {
          width: '460px',
          data: {
            bookingId: booking.id,
            customerName: dto.customerName,
            customerEmail: dto.customerEmail,
            branchName,
            appointmentDate: dto.appointmentDate,
            timeSlot: slot ? `${slot.startTime} – ${slot.endTime}` : '',
            appointmentType: typeName
          } satisfies BookingConfirmationDialogData
        });
      },
      error: (err) => {
        this.submitting = false;
        if (err?.status === 409) { this.openSnack('Selected time slot is already booked. Please choose another.'); this.tryLoadSlots(); }
        else this.openSnack('Booking failed. Please try again.');
      }
    });
  }

  formatDate(d: Date): string {
    const yyyy = d.getFullYear();
    const mm = String(d.getMonth() + 1).padStart(2, '0');
    const dd = String(d.getDate()).padStart(2, '0');
    return `${yyyy}-${mm}-${dd}`;
  }

  get f() { return this.form.controls; }

  openSnack(message: string): void {
    this.snack.open(message, 'Close', { duration: 3500 });
  }

  slotLabel(s: TimeSlot): string {
    return `${s.startTime} - ${s.endTime}`;
  }
}
