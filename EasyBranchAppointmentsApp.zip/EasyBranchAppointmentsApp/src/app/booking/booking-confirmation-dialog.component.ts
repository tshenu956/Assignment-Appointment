import { Component, Inject } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogModule } from '@angular/material/dialog';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';

export interface BookingConfirmationDialogData {
  bookingId: number;
  customerName: string;
  customerEmail: string;
  branchName: string;
  appointmentDate: string;
  timeSlot: string;
  appointmentType: string;
}

@Component({
  selector: 'app-booking-confirmation-dialog',
  standalone: true,
  imports: [MatDialogModule, MatButtonModule, MatIconModule],
  template: `
    <h2 mat-dialog-title style="display:flex;align-items:center;gap:8px;">
      <mat-icon style="color:#2e7d32">mark_email_read</mat-icon>
      Booking Confirmed
    </h2>
    <mat-dialog-content>
      <div style="background:#f5f5f5;border:1px solid #e0e0e0;border-radius:6px;padding:16px;font-size:0.88rem;color:#424242;line-height:1.7;">
        <div style="font-weight:600;margin-bottom:8px;color:#212121;">Simulated confirmation email</div>
        <div><strong>To:</strong> {{ data.customerEmail }}</div>
        <div style="margin-top:6px;">Hello <strong>{{ data.customerName }}</strong>,</div>
        <div style="margin-top:6px;">Your appointment has been confirmed. Here are your booking details:</div>
        <div style="margin-top:12px;background:#fff;border:1px solid #c8e6c9;border-radius:4px;padding:12px;">
          <div style="margin-bottom:5px;">
            <span style="color:#757575;">Reference:</span>&nbsp;<strong>#{{ data.bookingId }}</strong>
          </div>
          <div style="margin-bottom:5px;">
            <span style="color:#757575;">Branch:</span>&nbsp;<strong>{{ data.branchName }}</strong>
          </div>
          <div style="margin-bottom:5px;">
            <span style="color:#757575;">Date:</span>&nbsp;<strong>{{ data.appointmentDate }}</strong>
          </div>
          <div style="margin-bottom:5px;">
            <span style="color:#757575;">Time:</span>&nbsp;<strong>{{ data.timeSlot }}</strong>
          </div>
          <div>
            <span style="color:#757575;">Purpose:</span>&nbsp;<strong>{{ data.appointmentType }}</strong>
          </div>
        </div>
        <div style="margin-top:10px;color:#1565c0;font-size:0.82rem;">
          To cancel your appointment, visit the cancellation page and use your booking reference and email address.
        </div>
      </div>
    </mat-dialog-content>
    <mat-dialog-actions align="end" style="padding:12px 24px 16px;">
      <button mat-raised-button color="primary" mat-dialog-close>Done</button>
    </mat-dialog-actions>
  `
})
export class BookingConfirmationDialogComponent {
  constructor(@Inject(MAT_DIALOG_DATA) public data: BookingConfirmationDialogData) {}
}
