import { Component, Inject } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogModule, MatDialogRef } from '@angular/material/dialog';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatSnackBar, MatSnackBarModule } from '@angular/material/snack-bar';

export interface CredentialsDialogData {
  username: string;
  password: string;
}

@Component({
  selector: 'app-credentials-dialog',
  standalone: true,
  imports: [MatDialogModule, MatButtonModule, MatIconModule, MatSnackBarModule],
  template: `
    <h2 mat-dialog-title style="display:flex;align-items:center;gap:8px;">
      <mat-icon style="color:#3f51b5">mark_email_read</mat-icon>
      Admin Account Created
    </h2>
    <mat-dialog-content>
      <div style="background:#f5f5f5;border:1px solid #e0e0e0;border-radius:6px;padding:16px;font-size:0.88rem;color:#424242;line-height:1.7;">
        <div style="font-weight:600;margin-bottom:8px;color:#212121;">Simulated welcome email</div>
        <div>Hello <strong>{{ data.username }}</strong>,</div>
        <div style="margin-top:6px;">Your admin account has been created. Use the following credentials to log in:</div>
        <div style="margin-top:12px;background:#fff;border:1px solid #c5cae9;border-radius:4px;padding:12px;">
          <div style="margin-bottom:6px;">
            <span style="color:#757575;">Username:</span>&nbsp;<strong>{{ data.username }}</strong>
          </div>
          <div>
            <span style="color:#757575;">Password:</span>&nbsp;<strong style="font-family:monospace;letter-spacing:1px;">{{ data.password }}</strong>
          </div>
        </div>
        <div style="margin-top:10px;color:#e65100;font-size:0.82rem;">
          Please change your password after first login.
        </div>
      </div>
    </mat-dialog-content>
    <mat-dialog-actions align="end" style="padding:12px 24px 16px;gap:8px;">
      <button mat-stroked-button (click)="copy()">
        <mat-icon>content_copy</mat-icon> Copy Credentials
      </button>
      <button mat-raised-button color="primary" mat-dialog-close>Done</button>
    </mat-dialog-actions>
  `
})
export class CredentialsDialogComponent {
  constructor(
    public dialogRef: MatDialogRef<CredentialsDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: CredentialsDialogData,
    private snack: MatSnackBar
  ) {}

  copy(): void {
    const text = `Username: ${this.data.username}\nPassword: ${this.data.password}`;
    navigator.clipboard.writeText(text).then(() => {
      this.snack.open('Credentials copied to clipboard', 'Close', { duration: 2000 });
    });
  }
}
