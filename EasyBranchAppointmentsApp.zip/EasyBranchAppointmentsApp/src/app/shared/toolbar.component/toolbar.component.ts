import { Component, inject } from '@angular/core';
import { Router, RouterModule, RouterOutlet } from '@angular/router';
import { MatToolbarModule } from '@angular/material/toolbar';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatSidenavModule } from '@angular/material/sidenav';
import { MatListModule } from '@angular/material/list';
import { MatDividerModule } from '@angular/material/divider';
import { MatTooltipModule } from '@angular/material/tooltip';
import { CdkScrollableModule } from '@angular/cdk/scrolling';
import { AuthService } from '../../services/AuthService';

@Component({
  selector: 'app-toolbar',
  standalone: true,
  imports: [
    RouterModule,
    RouterOutlet,
    MatToolbarModule,
    MatButtonModule,
    MatIconModule,
    MatSidenavModule,
    MatListModule,
    MatDividerModule,
    MatTooltipModule,
    CdkScrollableModule
  ],
  template: `
    <mat-sidenav-container class="shell">

      <!-- ── Side drawer ── -->
      <mat-sidenav #sidenav mode="over" class="sidenav">

        <div class="sidenav-brand">
          <mat-icon class="brand-logo">event</mat-icon>
          <div>
            <div class="brand-name">Branch Appointments</div>
            <div class="brand-sub">Management System</div>
          </div>
        </div>

        <mat-divider />

        <mat-nav-list class="nav-list">
          <div class="nav-section">Main</div>

          <a mat-list-item
             routerLink="/"
             routerLinkActive="nav-active"
             [routerLinkActiveOptions]="{ exact: true }"
             (click)="sidenav.close()">
            <mat-icon matListItemIcon>schedule</mat-icon>
            <span matListItemTitle>Book Appointment</span>
          </a>

          <a mat-list-item
             routerLink="/admin"
             routerLinkActive="nav-active"
             (click)="sidenav.close()">
            <mat-icon matListItemIcon>dashboard</mat-icon>
            <span matListItemTitle>Admin Dashboard</span>
          </a>

          <mat-divider class="section-divider" />
          <div class="nav-section">Account</div>

          @if (isLoggedIn()) {
            <mat-list-item class="nav-logout" (click)="logout(); sidenav.close()">
              <mat-icon matListItemIcon>logout</mat-icon>
              <span matListItemTitle>Logout</span>
            </mat-list-item>
          } @else {
            <a mat-list-item
               routerLink="/login"
               routerLinkActive="nav-active"
               (click)="sidenav.close()">
              <mat-icon matListItemIcon>login</mat-icon>
              <span matListItemTitle>Login</span>
            </a>
          }
        </mat-nav-list>

      </mat-sidenav>

      <!-- ── Main content ── -->
      <mat-sidenav-content cdkScrollable>

        <mat-toolbar color="primary" class="topbar">
          <button mat-icon-button
                  (click)="sidenav.toggle()"
                  matTooltip="Open menu"
                  aria-label="Toggle navigation menu">
            <mat-icon>menu</mat-icon>
          </button>
          <span class="topbar-title">Branch Appointments</span>
          <span class="spacer"></span>
          @if (isLoggedIn()) {
            <button mat-button (click)="logout()" matTooltip="Sign out">
              <mat-icon>logout</mat-icon>
              <span class="btn-label">Logout</span>
            </button>
          } @else {
            <a mat-button routerLink="/login" matTooltip="Sign in">
              <mat-icon>login</mat-icon>
              <span class="btn-label">Login</span>
            </a>
          }
        </mat-toolbar>

        <router-outlet />

      </mat-sidenav-content>

    </mat-sidenav-container>
  `,
  styles: [`
    /* Shell */
    .shell {
      height: 100vh;
    }

    /* Required for Angular CDK overlay to position mat-select panels correctly.
       Without overflow:auto the scroll container is not measurable and all overlays
       (dropdowns, date pickers, etc.) fall back to top:0 left:0 — the top-left corner. */
    mat-sidenav-content {
      overflow-y: auto;
    }

    /* ── Sidenav ── */
    .sidenav {
      width: 264px;
      background: #fff;
      border-right: 1px solid #e0e0e0;
    }

    .sidenav-brand {
      display: flex;
      align-items: center;
      gap: 12px;
      padding: 20px 18px;
      background: #3f51b5;
      color: #fff;
    }

    .brand-logo {
      font-size: 34px;
      height: 34px;
      width: 34px;
      flex-shrink: 0;
    }

    .brand-name {
      font-size: 14px;
      font-weight: 600;
      line-height: 1.3;
      letter-spacing: 0.1px;
    }

    .brand-sub {
      font-size: 10px;
      opacity: 0.75;
      text-transform: uppercase;
      letter-spacing: 0.8px;
      margin-top: 2px;
    }

    .nav-list {
      padding-top: 8px;
    }

    .nav-section {
      padding: 14px 18px 4px;
      font-size: 10px;
      font-weight: 700;
      text-transform: uppercase;
      letter-spacing: 1.2px;
      color: #9e9e9e;
      pointer-events: none;
    }

    .section-divider {
      margin: 8px 0;
    }

    .nav-active {
      background: rgba(63, 81, 181, 0.08) !important;
      border-left: 3px solid #3f51b5;
      color: #3f51b5;
    }

    .nav-active mat-icon {
      color: #3f51b5;
    }

    .nav-logout {
      cursor: pointer;
    }

    .nav-logout:hover {
      background: rgba(244, 67, 54, 0.06);
    }

    /* ── Top bar ── */
    .topbar {
      position: sticky;
      top: 0;
      z-index: 100;
      box-shadow: 0 2px 6px rgba(0, 0, 0, 0.18);
    }

    .topbar-title {
      font-size: 17px;
      font-weight: 600;
      letter-spacing: 0.2px;
      margin-left: 8px;
    }

    .spacer {
      flex: 1 1 auto;
    }

    .btn-label {
      margin-left: 4px;
    }

    @media (max-width: 480px) {
      .btn-label {
        display: none;
      }
    }
  `]
})
export class AppToolbarComponent {
  private auth = inject(AuthService);
  private router = inject(Router);

  isLoggedIn(): boolean {
    return this.auth.isLoggedIn();
  }

  logout(): void {
    this.auth.logout();
    this.router.navigateByUrl('/login');
  }
}