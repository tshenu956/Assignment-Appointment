import { Component, OnInit, ViewChild, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { BranchService } from '../services/branchService';
import { TimeslotService } from '../services/timeslotService';
import { BookingService } from '../services/booking.Service';
import { AppointmentTypeService } from '../services/appointmentTypeService';
import { AuthService } from '../services/AuthService';
import { Branch } from '../models/branch.model';
import { TimeSlot } from '../models/timeslot.model';
import { Booking } from '../models/booking.model';
import { AppointmentType } from '../models/appointment-type.model';
import { FormBuilder, ReactiveFormsModule, Validators } from '@angular/forms';
import { Observable } from 'rxjs';
import { filter } from 'rxjs/operators';

import { MatCardModule } from '@angular/material/card';
import { MatTableDataSource, MatTableModule } from '@angular/material/table';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatSelectModule } from '@angular/material/select';
import { MatInputModule } from '@angular/material/input';
import { MatButtonModule } from '@angular/material/button';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatNativeDateModule } from '@angular/material/core';
import { MatIconModule } from '@angular/material/icon';
import { MatSnackBar, MatSnackBarModule } from '@angular/material/snack-bar';
import { MatTabsModule } from '@angular/material/tabs';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { MatTooltipModule } from '@angular/material/tooltip';
import { MatDividerModule } from '@angular/material/divider';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatPaginator, MatPaginatorModule } from '@angular/material/paginator';
import { MatDialog, MatDialogModule } from '@angular/material/dialog';

import { ConfirmDialogComponent, ConfirmDialogData } from '../shared/confirm-dialog/confirm-dialog.component';
import { CredentialsDialogComponent, CredentialsDialogData } from '../shared/credentials-dialog/credentials-dialog.component';

@Component({
  selector: 'app-admin-dashboard',
  standalone: true,
  imports: [
    CommonModule,
    ReactiveFormsModule,
    MatCardModule,
    MatTableModule,
    MatFormFieldModule,
    MatSelectModule,
    MatInputModule,
    MatButtonModule,
    MatDatepickerModule,
    MatNativeDateModule,
    MatIconModule,
    MatSnackBarModule,
    MatTabsModule,
    MatProgressSpinnerModule,
    MatTooltipModule,
    MatDividerModule,
    MatCheckboxModule,
    MatPaginatorModule,
    MatDialogModule
  ],
  templateUrl: './admin-dashboard.html',
  styleUrls: ['./admin-dashboard.css']
})
export class AdminDashboardComponent implements OnInit {

  private fb = inject(FormBuilder);
  private branchesApi = inject(BranchService);
  private slotsApi = inject(TimeslotService);
  private bookingsApi = inject(BookingService);
  private appointmentTypesApi = inject(AppointmentTypeService);
  private authService = inject(AuthService);
  private snack = inject(MatSnackBar);
  private dialog = inject(MatDialog);

  // ── Paginators ─────────────────────────────────────
  // Setter-based @ViewChild: Angular calls these the instant the element enters
  // the DOM (even inside @if blocks), wiring the paginator to the data source
  // immediately rather than waiting for ngAfterViewInit (which runs before data loads).
  @ViewChild('branchPaginator') set branchPaginator(p: MatPaginator) {
    if (p) this.branchDataSource.paginator = p;
  }
  @ViewChild('slotPaginator') set slotPaginator(p: MatPaginator) {
    if (p) this.slotDataSource.paginator = p;
  }
  @ViewChild('typePaginator') set typePaginator(p: MatPaginator) {
    if (p) this.typeDataSource.paginator = p;
  }
  @ViewChild('adminPaginator') set adminPaginator(p: MatPaginator) {
    if (p) this.adminDataSource.paginator = p;
  }

  // ── Data sources ──────────────────────────────────
  branchDataSource = new MatTableDataSource<Branch>([]);
  slotDataSource = new MatTableDataSource<TimeSlot>([]);
  bookings: Booking[] = [];
  typeDataSource = new MatTableDataSource<AppointmentType>([]);
  adminDataSource = new MatTableDataSource<{ id: number; username: string }>([]);

  // ── Bookings server-side pagination ───────────────
  bookingTotalCount = 0;
  bookingPage = 1;
  bookingPageSize = 10;

  // ── Convenience getters for templates ────────────
  get branches(): Branch[] { return this.branchDataSource.data; }
  get timeSlots(): TimeSlot[] { return this.slotDataSource.data; }
  get appointmentTypes(): AppointmentType[] { return this.typeDataSource.data; }

  selectedBranchId: number | null = null;

  // ── Loading flags ─────────────────────────────────
  loadingBranches = false;
  loadingSlots = false;
  loadingBookings = false;
  loadingAppointmentTypes = false;
  loadingAdmins = false;

  // ── Forms ─────────────────────────────────────────
  branchForm = this.fb.group({
    name: ['', [Validators.required, Validators.minLength(2)]],
    address: ['', [Validators.required, Validators.minLength(4)]]
  });

  branchEditForm = this.fb.group({
    id: [0, Validators.required],
    name: ['', [Validators.required, Validators.minLength(2)]],
    address: ['', [Validators.required, Validators.minLength(4)]]
  });

  generateForm = this.fb.group({
    fromTime: ['', Validators.required],
    toTime: ['', Validators.required],
    duration: [30, Validators.required]
  });

  bookingFilterForm = this.fb.group({
    appointmentDate: [null]
  });

  appointmentTypeForm = this.fb.group({
    name: ['', [Validators.required, Validators.minLength(2)]],
    description: ['']
  });

  adminForm = this.fb.group({
    username: ['', [Validators.required, Validators.minLength(3), Validators.maxLength(50)]]
  });

  // ── Slot generator ────────────────────────────────
  previewSlots: { startTime: string; endTime: string }[] = [];
  savingSlots = false;

  // ── Bulk selection ────────────────────────────────
  selectedSlotIds = new Set<number>();
  selectedBranchIds = new Set<number>();
  selectedBookingIds = new Set<number>();

  // ── Table column definitions ──────────────────────
  displayedSlots    = ['select', 'id', 'startTime', 'endTime', 'actions'];
  displayedBranches = ['select', 'id', 'name', 'address', 'actions'];
  displayedBookings = ['select', 'id', 'date', 'time', 'customer', 'email', 'appointmentType', 'status', 'actions'];
  displayedAppointmentTypes = ['id', 'name', 'description', 'actions'];
  displayedAdmins = ['username', 'actions'];

  // ── Getters ───────────────────────────────────────
  get selectedBranchName(): string {
    return this.branchDataSource.data.find(b => b.id === this.selectedBranchId)?.name ?? 'None selected';
  }

  get allSlotsSelected(): boolean {
    return this.slotDataSource.data.length > 0 && this.slotDataSource.data.every(s => this.selectedSlotIds.has(s.id));
  }
  get someSlotSelected(): boolean {
    return this.selectedSlotIds.size > 0 && !this.allSlotsSelected;
  }

  get allBranchesSelected(): boolean {
    return this.branchDataSource.data.length > 0 && this.branchDataSource.data.every(b => this.selectedBranchIds.has(b.id));
  }
  get someBranchSelected(): boolean {
    return this.selectedBranchIds.size > 0 && !this.allBranchesSelected;
  }

  get selectableBookings(): Booking[] {
    return this.bookings.filter(b => b.status !== 'CANCELLED');
  }
  get allBookingsSelected(): boolean {
    return this.selectableBookings.length > 0 && this.selectableBookings.every(b => this.selectedBookingIds.has(b.id));
  }
  get someBookingSelected(): boolean {
    return this.selectedBookingIds.size > 0 && !this.allBookingsSelected;
  }

  // ── Lifecycle ─────────────────────────────────────
  ngOnInit(): void {
    this.loadBranches();
    this.loadAppointmentTypes();
    this.loadAdmins();
  }


  // ── Confirmation dialog helper ────────────────────
  private confirm(data: ConfirmDialogData): Observable<boolean> {
    return this.dialog.open(ConfirmDialogComponent, {
      width: '380px',
      data,
      autoFocus: false
    }).afterClosed().pipe(filter((r): r is boolean => r === true));
  }

  // ── Branches ──────────────────────────────────────
  loadBranches(): void {
    this.loadingBranches = true;
    this.branchesApi.getBranches().subscribe({
      next: bs => {
        this.branchDataSource.data = bs;
        this.loadingBranches = false;
        this.selectedBranchIds.clear();
        if (bs.length && !this.selectedBranchId) {
          this.selectedBranchId = bs[0].id;
          this.onBranchChanged();
        }
      },
      error: (err) => {
        this.loadingBranches = false;
        this.openSnack(this.errMsg(err, 'Failed to load branches'));
      }
    });
  }

  createBranch(): void {
    if (this.branchForm.invalid) return;
    const payload = { name: this.branchForm.value.name!.trim(), address: this.branchForm.value.address!.trim() };
    this.branchesApi.createBranch(payload).subscribe({
      next: b => {
        this.branchForm.reset();
        this.openSnack('Branch created');
        this.loadBranches();
        this.selectedBranchId = b.id;
        this.onBranchChanged();
      },
      error: (err) => this.openSnack(this.errMsg(err, 'Failed to create branch'))
    });
  }

  startEditBranch(b: Branch): void {
    this.branchEditForm.patchValue({ id: b.id, name: b.name, address: b.address });
  }

  saveEditBranch(): void {
    if (this.branchEditForm.invalid) return;
    const { id, name, address } = this.branchEditForm.value;
    this.branchesApi.updateBranch(Number(id), { name: name!.trim(), address: address!.trim() }).subscribe({
      next: () => {
        this.openSnack('Branch updated');
        this.branchEditForm.reset();
        this.loadBranches();
      },
      error: (err) => this.openSnack(this.errMsg(err, 'Failed to update branch'))
    });
  }

  deleteBranch(id: number): void {
    this.confirm({
      title: 'Delete Branch',
      message: 'Delete this branch? This cannot be undone.'
    }).subscribe(() => {
      this.branchesApi.deleteBranch(id).subscribe({
        next: () => {
          this.openSnack('Branch deleted');
          if (this.selectedBranchId === id) this.selectedBranchId = null;
          this.loadBranches();
          this.slotDataSource.data = [];
          this.bookings = [];
        },
        error: (err) => this.openSnack(this.errMsg(err, 'Failed to delete branch (ensure no related data)'))
      });
    });
  }

  toggleBranch(id: number): void {
    this.selectedBranchIds.has(id) ? this.selectedBranchIds.delete(id) : this.selectedBranchIds.add(id);
  }

  toggleAllBranches(): void {
    if (this.allBranchesSelected) this.selectedBranchIds.clear();
    else this.branchDataSource.data.forEach(b => this.selectedBranchIds.add(b.id));
  }

  deleteSelectedBranches(): void {
    const ids = [...this.selectedBranchIds];
    this.confirm({
      title: 'Delete Branches',
      message: `Delete ${ids.length} selected branch${ids.length !== 1 ? 'es' : ''}?`
    }).subscribe(() => {
      this.branchesApi.deleteBranchesBulk(ids).subscribe({
        next: (res) => {
          let msg = `${res.deleted} branch${res.deleted !== 1 ? 'es' : ''} deleted`;
          if (res.skipped.length) msg += `, ${res.skipped.length} skipped (have related data)`;
          this.openSnack(msg);
          this.selectedBranchIds.clear();
          if (this.selectedBranchId && ids.includes(this.selectedBranchId)) this.selectedBranchId = null;
          this.loadBranches();
        },
        error: (err) => this.openSnack(this.errMsg(err, 'Failed to delete branches'))
      });
    });
  }

  onBranchChanged(): void {
    this.loadSlots();
    this.bookingPage = 1;
    this.loadBookings();
  }

  // ── Time Slots ────────────────────────────────────
  loadSlots(): void {
    const branchId = this.selectedBranchId;
    if (!branchId) { this.slotDataSource.data = []; return; }
    this.loadingSlots = true;
    this.slotsApi.getByBranch(branchId).subscribe({
      next: slots => {
        this.slotDataSource.data = slots;
        this.loadingSlots = false;
        this.selectedSlotIds.clear();
      },
      error: (err) => {
        this.loadingSlots = false;
        this.openSnack(this.errMsg(err, 'Failed to load time slots'));
      }
    });
  }

  generatePreview(): void {
    if (this.generateForm.invalid) return;
    const { fromTime, toTime, duration } = this.generateForm.value;
    const toMinutes = (t: string) => { const [h, m] = t!.split(':').map(Number); return h * 60 + m; };
    const pad = (n: number) => String(n).padStart(2, '0');
    const toHHMMSS = (mins: number) => `${pad(Math.floor(mins / 60))}:${pad(mins % 60)}:00`;
    const fromMin = toMinutes(fromTime!), toMin = toMinutes(toTime!), dur = Number(duration);
    if (toMin <= fromMin) { this.openSnack('End time must be after start time'); return; }
    const slots: { startTime: string; endTime: string }[] = [];
    for (let s = fromMin; s + dur <= toMin; s += dur)
      slots.push({ startTime: toHHMMSS(s), endTime: toHHMMSS(s + dur) });
    if (slots.length === 0) { this.openSnack('No complete slots fit in the selected range'); return; }
    this.previewSlots = slots;
  }

  removePreviewSlot(index: number): void { this.previewSlots.splice(index, 1); }
  clearPreview(): void { this.previewSlots = []; }

  saveAllSlots(): void {
    if (!this.selectedBranchId || this.previewSlots.length === 0) return;
    this.savingSlots = true;
    this.slotsApi.createSlotsBulk(this.selectedBranchId, this.previewSlots).subscribe({
      next: (res) => {
        this.savingSlots = false;
        let msg = `${res.created} slot${res.created !== 1 ? 's' : ''} created`;
        if (res.skipped.length > 0) msg += `, ${res.skipped.length} skipped (overlap)`;
        this.openSnack(msg);
        this.previewSlots = [];
        this.generateForm.reset({ duration: 30 });
        this.loadSlots();
      },
      error: (err) => {
        this.savingSlots = false;
        this.openSnack(this.errMsg(err, 'Failed to save slots'));
      }
    });
  }

  toggleSlot(id: number): void {
    this.selectedSlotIds.has(id) ? this.selectedSlotIds.delete(id) : this.selectedSlotIds.add(id);
  }

  toggleAllSlots(): void {
    if (this.allSlotsSelected) this.selectedSlotIds.clear();
    else this.slotDataSource.data.forEach(s => this.selectedSlotIds.add(s.id));
  }

  deleteSelectedSlots(): void {
    const ids = [...this.selectedSlotIds];
    this.confirm({
      title: 'Delete Time Slots',
      message: `Delete ${ids.length} selected slot${ids.length !== 1 ? 's' : ''}?`
    }).subscribe(() => {
      this.slotsApi.deleteSlotsBulk(ids).subscribe({
        next: (res) => {
          let msg = `${res.deleted} slot${res.deleted !== 1 ? 's' : ''} deleted`;
          if (res.skipped.length) msg += `, ${res.skipped.length} skipped (have bookings)`;
          this.openSnack(msg);
          this.selectedSlotIds.clear();
          this.loadSlots();
        },
        error: (err) => this.openSnack(this.errMsg(err, 'Failed to delete slots'))
      });
    });
  }

  deleteSlot(id: number): void {
    this.confirm({
      title: 'Delete Time Slot',
      message: 'Delete this time slot?'
    }).subscribe(() => {
      this.slotsApi.deleteSlot(id).subscribe({
        next: () => {
          this.openSnack('Time slot deleted');
          this.loadSlots();
        },
        error: (err) => this.openSnack(this.errMsg(err, 'Failed to delete time slot'))
      });
    });
  }

  // ── Bookings ──────────────────────────────────────
  loadBookings(): void {
    const branchId = this.selectedBranchId ?? undefined;
    const dateCtrl = this.bookingFilterForm.value.appointmentDate as Date | null;
    const date = dateCtrl ? this.formatDate(dateCtrl) : undefined;
    this.loadingBookings = true;
    this.bookingsApi.listPaged(branchId, date, this.bookingPage, this.bookingPageSize).subscribe({
      next: res => {
        this.bookings = res.items ?? [];
        this.bookingTotalCount = res.totalCount ?? 0;
        this.loadingBookings = false;
        this.selectedBookingIds.clear();
      },
      error: (err) => {
        this.loadingBookings = false;
        this.openSnack(this.errMsg(err, 'Failed to load bookings'));
      }
    });
  }

  onBookingPageChange(event: { pageIndex: number; pageSize: number }): void {
    this.bookingPage = event.pageIndex + 1;
    this.bookingPageSize = event.pageSize;
    this.loadBookings();
  }

  toggleBooking(id: number): void {
    this.selectedBookingIds.has(id) ? this.selectedBookingIds.delete(id) : this.selectedBookingIds.add(id);
  }

  toggleAllBookings(): void {
    if (this.allBookingsSelected) this.selectedBookingIds.clear();
    else this.selectableBookings.forEach(b => this.selectedBookingIds.add(b.id));
  }

  cancelSelectedBookings(): void {
    const ids = [...this.selectedBookingIds];
    this.confirm({
      title: 'Cancel Bookings',
      message: `Cancel ${ids.length} selected booking${ids.length !== 1 ? 's' : ''}?`,
      confirmLabel: 'Cancel Bookings',
      confirmColor: 'warn'
    }).subscribe(() => {
      this.bookingsApi.cancelBulk(ids).subscribe({
        next: (res) => {
          this.openSnack(`${res.cancelled} booking${res.cancelled !== 1 ? 's' : ''} cancelled`);
          this.selectedBookingIds.clear();
          this.loadBookings();
        },
        error: (err) => this.openSnack(this.errMsg(err, 'Failed to cancel bookings'))
      });
    });
  }

  cancelBooking(b: Booking): void {
    this.confirm({
      title: 'Cancel Booking',
      message: `Cancel booking #${b.id} for ${b.customerName}?`,
      confirmLabel: 'Cancel Booking',
      confirmColor: 'warn'
    }).subscribe(() => {
      this.bookingsApi.cancel(b.id).subscribe({
        next: () => {
          this.openSnack('Booking cancelled');
          this.loadBookings();
        },
        error: (err) => this.openSnack(this.errMsg(err, 'Failed to cancel booking'))
      });
    });
  }

  // ── Appointment Types ─────────────────────────────
  loadAppointmentTypes(): void {
    this.loadingAppointmentTypes = true;
    this.appointmentTypesApi.getAll().subscribe({
      next: types => {
        this.typeDataSource.data = types;
        this.loadingAppointmentTypes = false;
      },
      error: (err) => {
        this.loadingAppointmentTypes = false;
        this.openSnack(this.errMsg(err, 'Failed to load appointment types'));
      }
    });
  }

  createAppointmentType(): void {
    if (this.appointmentTypeForm.invalid) return;
    const { name, description } = this.appointmentTypeForm.value;
    this.appointmentTypesApi.create(name!.trim(), description?.trim() ?? '').subscribe({
      next: () => {
        this.openSnack('Appointment type created');
        this.appointmentTypeForm.reset();
        this.loadAppointmentTypes();
      },
      error: (err) => this.openSnack(this.errMsg(err, 'Failed to create appointment type'))
    });
  }

  deleteAppointmentType(id: number): void {
    this.confirm({
      title: 'Delete Appointment Type',
      message: 'Delete this appointment type?'
    }).subscribe(() => {
      this.appointmentTypesApi.delete(id).subscribe({
        next: () => {
          this.openSnack('Appointment type deleted');
          this.loadAppointmentTypes();
        },
        error: (err) => this.openSnack(this.errMsg(err, 'Failed to delete appointment type'))
      });
    });
  }

  // ── Admins ────────────────────────────────────────
  loadAdmins(): void {
    this.loadingAdmins = true;
    this.authService.getAdmins().subscribe({
      next: admins => {
        this.adminDataSource.data = admins;
        this.loadingAdmins = false;
      },
      error: (err) => {
        this.loadingAdmins = false;
        this.openSnack(this.errMsg(err, 'Failed to load admins'));
      }
    });
  }

  registerAdmin(): void {
    if (this.adminForm.invalid) return;
    const username = this.adminForm.value.username!.trim();
    const password = this.generatePassword();
    this.authService.register(username, password).subscribe({
      next: () => {
        this.adminForm.reset();
        this.loadAdmins();
        this.dialog.open(CredentialsDialogComponent, {
          width: '440px',
          disableClose: true,
          data: { username, password } satisfies CredentialsDialogData
        });
      },
      error: (err) => this.openSnack(this.errMsg(err, 'Failed to register admin'))
    });
  }

  private generatePassword(): string {
    const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789!@#$%&*';
    const array = new Uint8Array(16);
    crypto.getRandomValues(array);
    return Array.from(array, b => chars[b % chars.length]).join('');
  }

  deleteAdmin(admin: { id: number; username: string }): void {
    this.confirm({
      title: 'Delete Admin',
      message: `Delete admin "${admin.username}"? This cannot be undone.`,
      confirmLabel: 'Delete',
      confirmColor: 'warn'
    }).subscribe(() => {
      this.authService.deleteAdmin(admin.id).subscribe({
        next: () => {
          this.openSnack('Admin deleted');
          this.loadAdmins();
        },
        error: (err) => this.openSnack(this.errMsg(err, 'Failed to delete admin'))
      });
    });
  }

  get currentAdminId(): number | null {
    return this.authService.getCurrentAdminId();
  }

  // ── Utilities ─────────────────────────────────────
  openSnack(message: string): void {
    this.snack.open(message, 'Close', { duration: 3500 });
  }

  private errMsg(err: any, fallback: string): string {
    return typeof err?.error === 'string' ? err.error : (err?.error?.message ?? fallback);
  }

  formatDate(d: Date): string {
    const yyyy = d.getFullYear();
    const mm = String(d.getMonth() + 1).padStart(2, '0');
    const dd = String(d.getDate()).padStart(2, '0');
    return `${yyyy}-${mm}-${dd}`;
  }
}
