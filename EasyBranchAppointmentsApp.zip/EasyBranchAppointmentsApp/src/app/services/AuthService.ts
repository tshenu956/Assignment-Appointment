import { Injectable } from '@angular/core';

import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable, tap } from 'rxjs';
import { environment } from '../../environments/environment';

interface LoginResponse {
  token: string;
}


@Injectable({ 
  providedIn: 'root',
})
export class AuthService {
  
private baseUrl = `${environment.apiBase}/api/Auth`;
private tokenKey = 'appointment.jwt';

constructor(private http: HttpClient) {}

/** Registers an admin account (optional for prod; seed is fine). */
register(username: string, password: string): Observable<string> {
  return this.http.post(this.baseUrl + '/register', { username, password }, { responseType: 'text' });
}

/** Logs in and stores JWT token in localStorage. */
login(username: string, password: string): Observable<LoginResponse> {
  return this.http.post<LoginResponse>(this.baseUrl + '/login', { username, password }).pipe(
    tap(res => {
      if (res?.token) {
        localStorage.setItem(this.tokenKey, res.token);
      }
    })
  );
}

logout(): void {
  localStorage.removeItem(this.tokenKey);
}

get token(): string | null {
  return localStorage.getItem(this.tokenKey);
}

isLoggedIn(): boolean {
  return !!this.token;
}

/** Builds auth headers for protected endpoints (used later in Admin module). */
getAuthHeaders(): HttpHeaders {
  const token = this.token;
  return new HttpHeaders(
    token ? { Authorization: `Bearer ${token}` } : {}
  );
}

/** Returns all admins (id + username only, no password). */
getAdmins(): Observable<{ id: number; username: string }[]> {
  return this.http.get<{ id: number; username: string }[]>(this.baseUrl + '/admins');
}

/** Deletes the admin with the given id. */
deleteAdmin(id: number): Observable<void> {
  return this.http.delete<void>(`${this.baseUrl}/admins/${id}`);
}

/** Decodes the JWT sub claim to get the current admin's numeric id. */
getCurrentAdminId(): number | null {
  const token = this.token;
  if (!token) return null;
  try {
    const payloadB64 = token.split('.')[1].replace(/-/g, '+').replace(/_/g, '/');
    const payload = JSON.parse(atob(payloadB64));
    const sub = payload['sub'];
    return sub != null ? parseInt(sub, 10) : null;
  } catch {
    return null;
  }
}

}
