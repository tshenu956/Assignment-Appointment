import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Booking, CreateBookingDto } from '../models/booking.model';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { environment } from '../../environments/environment';

export interface BookingPage {
  items: Booking[];
  totalCount: number;
  totalPages: number;
  page: number;
  pageSize: number;
}

@Injectable({
  providedIn: 'root',
})
export class BookingService {

  private baseUrl = `${environment.apiBase}/api/Booking`;

  constructor(private http: HttpClient) {}

  // Public (customer)
  create(dto: CreateBookingDto): Observable<Booking> {
    return this.http.post<Booking>(this.baseUrl, dto);
  }

  // Admin — returns full page result for server-side pagination
  listPaged(branchId?: number, date?: string, page = 1, pageSize = 10): Observable<BookingPage> {
    let params = new HttpParams()
      .set('page', page)
      .set('pageSize', pageSize);
    if (branchId) params = params.set('branchId', branchId);
    if (date) params = params.set('date', date);
    return this.http.get<BookingPage>(this.baseUrl, { params });
  }

  // Keep list() for backward compat (booking component uses it)
  list(branchId?: number, date?: string): Observable<Booking[]> {
    let params = new HttpParams();
    if (branchId) params = params.set('branchId', branchId);
    if (date) params = params.set('date', date);
    return this.http.get<BookingPage>(this.baseUrl, { params }).pipe(
      map(res => res.items ?? [])
    );
  }

  cancel(id: number): Observable<void> {
    return this.http.delete<void>(`${this.baseUrl}/${id}`);
  }

  cancelBulk(ids: number[]): Observable<{ cancelled: number }> {
    return this.http.delete<{ cancelled: number }>(`${this.baseUrl}/bulk`, { body: { ids } });
  }
}
