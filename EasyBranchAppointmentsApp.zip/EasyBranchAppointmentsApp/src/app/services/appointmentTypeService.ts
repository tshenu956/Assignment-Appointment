import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { AppointmentType } from '../models/appointment-type.model';
import { environment } from '../../environments/environment';

@Injectable({ providedIn: 'root' })
export class AppointmentTypeService {
  private baseUrl = `${environment.apiBase}/api/AppointmentType`;

  constructor(private http: HttpClient) {}

  getAll(): Observable<AppointmentType[]> {
    return this.http.get<AppointmentType[]>(this.baseUrl);
  }

  create(name: string, description: string): Observable<AppointmentType> {
    return this.http.post<AppointmentType>(this.baseUrl, { name, description });
  }

  delete(id: number): Observable<void> {
    return this.http.delete<void>(`${this.baseUrl}/${id}`);
  }
}
