import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { TimeSlot } from '../models/timeslot.model';
import { Observable } from 'rxjs';
import { environment } from '../../environments/environment';

@Injectable({
  providedIn: 'root',
})
export class TimeslotService {
  
private baseUrl = `${environment.apiBase}/api/TimeSlot`;

constructor(private http: HttpClient) {}

/**
 * Get available slots for branch + date.
 * @param branchId number
 * @param date Date or string in 'YYYY-MM-DD'
 */


// Public (customer): availability by date
  getSlots(branchId: number, date: Date | string): Observable<TimeSlot[]> {
    const day = typeof date === 'string' ? date : this.toIsoDate(date);
    const url = `${this.baseUrl}/${branchId}?date=${encodeURIComponent(day)}`;
    return this.http.get<TimeSlot[]>(url);
  }

  // Admin: get all slots for a branch (no date filter)
  getByBranch(branchId: number): Observable<TimeSlot[]> {
    return this.http.get<TimeSlot[]>(`${this.baseUrl}/branch/${branchId}`);
  }

  // Admin: create slot
  createSlot(branchId: number, startTime: string, endTime: string): Observable<TimeSlot> {
    return this.http.post<TimeSlot>(this.baseUrl, { branchId, startTime, endTime });
  }

  // Admin: bulk create slots
  createSlotsBulk(branchId: number, slots: { startTime: string; endTime: string }[]): Observable<{ created: number; skipped: { startTime: string; endTime: string; reason: string }[] }> {
    return this.http.post<{ created: number; skipped: { startTime: string; endTime: string; reason: string }[] }>(`${this.baseUrl}/bulk`, { branchId, slots });
  }

  // Admin: delete slot
  deleteSlot(id: number): Observable<void> {
    return this.http.delete<void>(`${this.baseUrl}/${id}`);
  }

  // Admin: bulk delete slots
  deleteSlotsBulk(ids: number[]): Observable<{ deleted: number; skipped: { id: number; reason: string }[] }> {
    return this.http.delete<{ deleted: number; skipped: { id: number; reason: string }[] }>(`${this.baseUrl}/bulk`, { body: { ids } });
  }

  private toIsoDate(d: Date): string {
    const yyyy = d.getFullYear();
    const mm = String(d.getMonth() + 1).padStart(2, '0');
    const dd = String(d.getDate()).padStart(2, '0');
    return `${yyyy}-${mm}-${dd}`;
  }
}