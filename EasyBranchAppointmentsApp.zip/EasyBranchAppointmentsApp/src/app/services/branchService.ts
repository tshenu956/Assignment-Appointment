import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Branch } from '../models/branch.model';
import { Observable } from 'rxjs';
import { environment } from '../../environments/environment';


@Injectable({
  providedIn: 'root',
})
export class BranchService {
  private baseUrl = `${environment.apiBase}/api/Branch`;

  
constructor(private http: HttpClient) {}

getBranches(): Observable<Branch[]> {
  return this.http.get<Branch[]>(this.baseUrl);
  }

  // Admin CRUD (protected)
  createBranch(branch: Partial<Branch>): Observable<Branch> {
    return this.http.post<Branch>(this.baseUrl, branch);
  }

  updateBranch(id: number, branch: Partial<Branch>): Observable<Branch> {
    return this.http.put<Branch>(`${this.baseUrl}/${id}`, branch);
  }

  deleteBranch(id: number): Observable<void> {
    return this.http.delete<void>(`${this.baseUrl}/${id}`);
  }

  deleteBranchesBulk(ids: number[]): Observable<{ deleted: number; skipped: { id: number; reason: string }[] }> {
    return this.http.delete<{ deleted: number; skipped: { id: number; reason: string }[] }>(`${this.baseUrl}/bulk`, { body: { ids } });
  }

}
