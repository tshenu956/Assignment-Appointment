import { Routes } from '@angular/router';
import { BookingComponent } from './booking/Booking.Component';
import { Login } from './login/login';
import { AdminDashboardComponent } from './admin-dashboard/admin-dashboard';
import { AuthGuard } from './auth.guard';

export const routes: Routes = [
  { path: '', component: BookingComponent },
  { path: 'login', component: Login },
  { path: 'admin', component: AdminDashboardComponent, canActivate: [AuthGuard] },
  { path: '**', redirectTo: '' }
];
